---
id: "jack-ch-02-throwing-beans-summary"
chapter_id: "jack-ch-02-throwing-beans"
pov: "Jack"
characters:
  - "Jack"
  - "Jack's Mother"
  - "Nell"
beats:
  - "Jack returns without Dapple and tells his mother about Wren’s bargain."
  - "His mother condemns Jack for gambling away something her work had earned."
  - "She throws the beans into the muddy garden, where they begin to grow overnight."
spoilers_ok: true
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
Jack returns home with beans instead of money and discovers that believing in their magic does not excuse making the bargain without his mother. Exhausted and furious, she throws the beans through the window. Jack recognizes the harm in wagering the product of her labor, but during the night the discarded beans take root and begin to transform the cottage garden.