---
id: "jack-ch-02-throwing-beans"
book_id: "jack-house-above-rain"
part_id: "jack-part-01-bargain"
title: "Throwing the Beans Away"
cover_image_id: "jack-asset-02-throwing-beans"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
wiki_mentions:
  - id: "jack-ch-02-throwing-beans-mention-jack"
    wiki_page_id: "jack-wiki-jack"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-02-throwing-beans-mention-mother"
    wiki_page_id: "jack-wiki-jacks-mother"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-02-throwing-beans-mention-nell"
    wiki_page_id: "jack-wiki-nell"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-02-throwing-beans-mention-cottage"
    wiki_page_id: "jack-wiki-jacks-cottage"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-02-throwing-beans-mention-bellweather"
    wiki_page_id: "jack-wiki-bellweather-valley"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
---
His mother knew before he spoke.

She was at the table with the blue crock before her. She had emptied the savings beside it and arranged the coins into narrow stacks, allotting each one to the tax, the coach, food for the road. When Jack came in alone, she looked past him toward the yard.

“Where is Dapple?”

Jack shut the door. Nell remained outside beneath the eaves, which he considered cowardly until he remembered she did not have to come home with him at all.

“I met someone on the road.”

His mother’s hand flattened on the table.

“Where is the cow?”

He took the three beans from his pocket and laid them carefully beside the coins.

For several seconds she did not move. The fire ticked behind him. A shirt on the overhead line released a drop of water, which struck the floor with a soft, distinct tap.

“What are those?” she asked.

“They’re magic.”

Her face did not change, but the room seemed to contract around them.

Jack began quickly. He told her about Wren, the plans, the builder’s mark, the vine growing in the old man’s hand. He told her about the unpaid gold and the living road. He told her the cow was alive, sheltered, and eating better than she had eaten at home. He told her everything except how frightened Nell had looked when he made the bargain.

His mother listened without interrupting.

When he finished, she picked up one of the beans between finger and thumb.

“I asked you for money.”

“I know.”

“I asked you for one thing.”

“But these could be worth—”

She swept her arm across the table.

The stacks of coins flew. The blue crock struck the floor and shattered. Pennies rang against the hearthstones. One rolled beneath the dresser. The beans bounced, astonishingly green against the dull boards.

“Do you know what it cost to keep that cow alive through February?” she said.

Jack stepped back. He had seen his mother angry. He had seen her curse a torn sheet, a dishonest merchant, a frozen pump. He had never seen her like this. Color burned high across her cheekbones. Her breath shook, but her voice grew louder with every word.

“I carried water to that animal when the well froze. I cut reeds under the ice because we had no hay left. I sat in the byre for two nights while she was sick because if she died, we lost the milk, and if we lost the milk, we lost the house. I sold your father’s saw to buy her fodder. I went without supper so many times that spring you began pretending not to be hungry because you thought I didn’t know what you were doing.”

“Mam—”

“Do not *Mam* me as if I have misunderstood. I understand perfectly. I gave you the last thing we owned because I trusted you to sell it.”

“The man built the cloud.”

“The man says he built the cloud. The man says giants cheated him fifty years ago. The man says exactly the things a boy desperate for a miracle would need to hear.”

“Nell saw the plans.”

“Nell is fifteen!”

Her palm struck the table. The pies jumped on their board.

“I have spun until I could not straighten my fingers. I have washed the skin off my hands. I have baked and mended and begged people who owe me money to pay half of it. I had one plan left, Jack. One. And you traded it for beans.”

The last word broke in her throat.

Jack bent to gather them. “I can take them back.”

“And if he refuses? Will you trade him your boots? The roof? Me?”

He flinched. Regret passed across her face, but it did not cool the anger.

She snatched the beans from the floor, crossed to the window, and wrenched it open. Cold air shoved into the room, smelling of mud and chimney smoke.

“Let magic eat them,” she said. “Magic has eaten everything else.”

She threw them into the dark.

One vanished into the garden. One struck the stone path and skipped beneath the rain barrel. The third flashed silver as it fell into the black earth beside the wall.

His mother closed the window so hard the remaining pane cracked from corner to corner.

“Get out of my sight,” she said, very quietly, “before I say something I cannot call back.”

Jack went to the loft.

He lay fully dressed beneath his father’s old blanket while the house settled into silence below. He heard his mother sweep up the crock. He heard her moving the dresser to recover the lost penny. Much later, he heard her crying, once, as if the sound had been forced out of her. Then the spinning wheel began to turn.

Jack put his hands over his ears.

He still believed Wren. That was the worst of it. He believed the beans were magical and the road was real and the house above them contained more wealth than his mother could imagine. But belief did not restore the choice he had taken from her. He had gambled what she had earned, not what he had earned, and no possible treasure could make that decision wise before the treasure was won.

Sometime after midnight, the rain began again.

At first Jack thought the sound against the roof was hail. Then something scraped along the outer wall. The cottage timbers groaned. A cup fell from the shelf below and shattered. Jack sat up.

From the garden came a noise like roots tearing through a grave.

He reached the window as the earth opened.

Three pale shoots thrust out of the mud. They rose past him, twisting together, thickening as they grew. Leaves unfurled with damp explosive snaps, each broad enough to roof the cottage. The rain ran silver from their veins. Tendrils groped across the yard, found the stones, the pear tree, the chimney, and curled around them—not crushing, but holding, testing, climbing.

The stalk surged upward.

Jack leaned into the rain and watched it vanish into the darkness above. For one instant lightning spread inside the giants’ cloud, and the entire living road appeared: a braided green tower reaching from the cottage garden to the black foundations in the sky.

Then the dark closed over it.