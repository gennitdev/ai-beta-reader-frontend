---
id: "jack-ch-04-above-clouds-summary"
chapter_id: "jack-ch-04-above-clouds"
pov: "Jack"
characters:
  - "Jack"
  - "Nell"
beats:
  - "Jack and Nell emerge above the rain and see the cloud-house clearly."
  - "Wren’s brass mark admits them through a garden of cultivated weather."
  - "The living house recognizes them as maintenance workers and draws them inside."
spoilers_ok: true
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
Jack and Nell climb above the rain into brilliant sunlight and discover the Morrows’ impossible estate rooted in the cloud. They cross a garden where weather grows as fruit and flowers, then use Wren’s brass mark to enter the living house. Its corridors, clocks, and doors are inhabited by bound spirits that recognize the children as maintenance workers.