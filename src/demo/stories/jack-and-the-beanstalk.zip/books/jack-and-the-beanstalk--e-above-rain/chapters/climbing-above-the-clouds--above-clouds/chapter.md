---
id: "jack-ch-04-above-clouds"
book_id: "jack-house-above-rain"
part_id: "jack-part-02-above-rain"
title: "Climbing Above the Clouds"
cover_image_id: "jack-asset-04-climbing"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
wiki_mentions:
  - id: "jack-ch-04-above-clouds-mention-jack"
    wiki_page_id: "jack-wiki-jack"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-04-above-clouds-mention-nell"
    wiki_page_id: "jack-wiki-nell"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-04-above-clouds-mention-cloud-house"
    wiki_page_id: "jack-wiki-cloud-house"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-04-above-clouds-mention-weather-garden"
    wiki_page_id: "jack-wiki-weather-garden"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-04-above-clouds-mention-bellweather"
    wiki_page_id: "jack-wiki-bellweather-valley"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
---
They climbed above the rain.

Sunlight struck them like a door flung open.

The upper surface of the cloud stretched away in rolling white hills, brilliant beneath a sky so deeply blue it looked solid. The beanstalk rose from it dripping and jeweled. Far to the west, mountains floated above the lower clouds like islands. Jack could see the pale curve of the moon although it was morning.

And before them stood the house.

It did not resemble any house built by human hands. Black foundation stones rose from the cloud like cliffs, their faces veined with quartz and embedded with enormous shells. Walls of dark timber and green glass climbed through three separate tiers of weather. Copper pipes traveled along them in branching patterns, carrying quick blue flashes of captive lightning. Turrets emerged from the upper mist; bridges passed between roofs and vanished into gardens hanging in the air. Some windows reflected the blue morning. Others showed snow, sunset, or a red coast under unfamiliar stars.

The beanstalk ended in a walled garden.

Jack pulled himself over the rim and sank wrist-deep into black soil that muttered with distant thunder. Nell rolled onto her back beside him and lay breathing with her eyes shut.

“We looked,” she said. “I have seen it. It is very large. We can go.”

Jack had forgotten how to answer.

The garden beds were filled with weather. Rain lilies opened crystal petals and released small showers into silver basins. Hail-plums hung translucent among blue leaves, cold mist spilling from their skins. Vines climbed copper frames and bore round glass fruit; inside each one, a tiny wind worried at a swirl of dead leaves. At the end of the path stood a tree with a white trunk and no foliage. Thunder rolled in its branches.

Beyond it, three steps led to a kitchen door tall enough for the village church to pass through.

At the base of the lowest step, almost hidden by moss, was a second door no higher than Jack’s shoulder.

Three leaves twisted around a tower had been stamped into its brass.

Jack touched the mark.

The door opened its eye.

It had only one, a dark glass bead set above the latch. It considered Jack, then Nell.

“Maintenance,” it said.

Its voice was the sound of wood settling in an empty room.

“Yes,” Jack said.

“Name?”

From inside the wall, something whispered urgently, “Don’t.”

Jack’s mouth closed.

Nell leaned toward the eye. “Delayed,” she said.

“Name delayed,” the door repeated. “A common difficulty.”

The latch clicked.

They entered the house.

The passage had been built for human workmen. It ran between the outer wall and the rooms beyond, narrow and black, with copper conduits overhead and little doors placed at intervals along the wainscot. Dust lay thick on the floor. Here and there, tools remained where someone had abandoned them half a century before: a leather glove collapsed around the bones of its fingers, a green bottle furred with cobweb, a wooden ruler marked in human inches on one side and giant thumbs on the other.

The walls hummed. Jack put his palm against the plaster and felt something moving through it, a slow circulation like blood.

They passed a brass speaking tube.

“Still raining in the east bedroom,” it murmured. “Still raining. No one has slept there for thirty-two years.”

Farther on, a painted face in a little clock opened its eyes as they approached. It depicted a young man in a blue coat, his body ending at the shoulders where the clock case began.

“You’re groundborn,” he whispered.

Jack stopped. “Were you?”

The painted eyes flicked toward the ceiling. “Once.”

“What happened?”

The clock’s minute hand jerked forward.

“I gave them my name.”

Footsteps sounded somewhere beyond the wall.

Not giant footsteps. These were the small, irregular taps of the house shifting its own furniture.

The painted man shut his eyes. “Go.”

Jack and Nell went.

They found a wainscot door and opened it a crack.

Beyond lay the kitchen.