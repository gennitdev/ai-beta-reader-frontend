---
id: "jack-ch-07-after-fall"
book_id: "jack-house-above-rain"
part_id: "jack-part-03-bring-down-house"
title: "After the Fall"
cover_image_id: "jack-asset-07-after-fall"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
wiki_mentions:
  - id: "jack-ch-07-after-fall-mention-jack"
    wiki_page_id: "jack-wiki-jack"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-nell"
    wiki_page_id: "jack-wiki-nell"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-mother"
    wiki_page_id: "jack-wiki-jacks-mother"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-lord-morrow"
    wiki_page_id: "jack-wiki-lord-morrow"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-lady-morrow"
    wiki_page_id: "jack-wiki-lady-morrow"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-majesty"
    wiki_page_id: "jack-wiki-majesty"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-harp"
    wiki_page_id: "jack-wiki-truth-harp"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-wren"
    wiki_page_id: "jack-wiki-silas-wren"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-dapple"
    wiki_page_id: "jack-wiki-dapple"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-bellweather"
    wiki_page_id: "jack-wiki-bellweather-valley"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-cloud-house"
    wiki_page_id: "jack-wiki-cloud-house"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-weather-room"
    wiki_page_id: "jack-wiki-weather-room"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-07-after-fall-mention-cottage"
    wiki_page_id: "jack-wiki-jacks-cottage"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
---
The cloud-house moved.

At first Jack felt only the small upward pull beneath his ribs that came when a hoist began to lower. Then every hanging chain in the weather room lifted toward the ceiling. Water sloshed from its pipes. The valley below widened.

Lady Morrow seized the key. Her hand closed around the iron above Jack, each finger longer than his arm. The mechanism stopped.

“You will crush them,” she said. Her composure had broken at last. “The eastern foundations will strike first. The house will roll.”

The tuning peg in Nell’s pocket grew hot. Through it came a faint voice from the earth.

“Hold east,” Jack’s mother said. “Release north half. West, take the strain.”

The house tilted back into balance.

Lady Morrow stared at the valley. “Who is doing that?”

Jack looked up at her. “My mother.”

The giant tightened her grip.

Then every clock in the house struck at once.

The sound was deafening. Bells rang in the walls. Doors flew open. From vents, keyholes, speaking tubes, and carved mouths came the voices of the people the house had taken.

“Name given under duress,” sang the harp. “Service unlawfully extended. Witness retained in wall, stair, clock, bell, chair, and door.”

The house shuddered—not from the descent, but from within.

The chair behind Lady Morrow moved sharply and struck the backs of her knees, as a chair had once moved to tip two children off a table and out of her reach. She stumbled. Her hand left the iron. The key spun.

The opal pointed down.

Below, the anchor fires became five bright stars.

Silas Wren stood at the northern stone with an axe in his hands.

The black suspension line ran through a groove at his feet, visible now as a rope of green-white light. One stroke would sever it. The house would tip north, away from most of the village and toward the old yellow-gray cottage where Ada lay beneath her purple asters.

Wren raised the axe.

The tuning fork beside the stone sang in the harp’s voice.

“Ada Wren,” it said. “Witness to suspension covenant. Statement entered: *No house is safely raised by treating the lives beneath it as empty ground.*”

Wren closed his eyes.

The axe fell from his hands.

He seized the release wheel with the others.

“North ready!” he shouted.

The house descended through its own cloud.

Rain struck the glass dome. The weather room vanished into gray. Lightning climbed the copper machinery. Lord Morrow entered through the opposite arch, beard unbound, black coat streaming behind him. When he saw the downward-pointing key, he gave a cry that shook dust from the beams.

Jack dropped from the regulator.

“Go!” Nell shouted.

The goose had already gone.

They followed her into a house coming apart from the sky.

Rooms tilted and righted themselves. Cupboards opened, releasing plates that flew like white wheels. Summer escaped from the orchard dome and rushed down the gallery in a warm wind full of apple blossom. A jar shattered; snow filled the stairwell. The miniature ship burst from its bottle on a green wave and sailed across the carpet.

The goose ran through it all, wings spread, honking with what sounded like joy.

The harp on Jack’s back sang directions. “Left. Wainscot. Under. Up.”

“Choose one!” Nell shouted.

“All are true.”

“I hate magical objects!”

They reached the dining hall and found the doors sealed.

The house dropped another hundred feet. The chandelier swung almost horizontal. Jack and Nell were thrown onto the leg of the dining table. The goose flapped to a chair, scrabbled up its upholstery, and vanished onto the tabletop.

Lord Morrow entered behind them.

They climbed.

Jack pulled himself over the table edge into a wrecked landscape of supper. A teapot had overturned, spilling a steaming lake through the white cloth. Plates slid slowly downhill as the house tipped. Green-heron cups rolled on their sides. Beyond the edge, the carpet lay far below, its woven flowers heaving as trapped figures struggled upward through the wool.

Nell crawled out beside him. The goose stood on an inverted sugar bowl, feathers blazing white in the lightning.

Lord Morrow’s hand came down.

They ran behind a teacup. His fingers closed around it, lifted it away, and exposed them. Jack saw the lines in the giant’s palm, deep as ditches.

The harp sounded a chord against Jack’s back.

Every chair at the table drew backward.

Lord Morrow lost his balance. His hand struck the cloth. The silver spoon leapt into the air, turned once, and landed with its handle bridging the table and a sideboard below.

“That is not structurally persuasive,” Nell said.

“Do you have another bridge?”

“I have many criticisms.”

“Bring them.”

Jack stepped onto the spoon.

It bowed beneath him. Tea ran along its handle, making the silver slick. Halfway across, the house emerged from the bottom of the cloud.

Bellweather Valley appeared beyond the windows.

It was night below. Hundreds of lanterns burned along the roads. The foundations of the house descended toward the open moor north of the village, vapor tearing from their black stone. People ran beside the moving shadow like sparks beside a falling mountain.

The giant’s finger hooked the spoon behind Jack.

Silver bent. Nell jumped for the sideboard and caught its carved edge. Jack swung from his harness. The harp struck the wood, strings crying out. The goose launched herself over his head, beat her wings in Lord Morrow’s face, and dropped heavily onto Nell.

Nell screamed something impolite.

Jack found the sideboard with one boot. Nell caught his wrist. Together they rolled into an open drawer as the spoon fell away.

The drawer slammed shut around them.

Darkness.

Jack heard the deep impact of Lord Morrow’s hand against the wood. Nell’s breath came fast beside him. The goose sat on both their legs.

Then the back of the drawer opened its mouth.

“Maintenance,” said the house.

They crawled through.

The passage carried them downward as if the walls themselves were handing them from room to room. Hatches opened before them and sealed behind. The painted man in the blue clock watched them pass, his face no longer painted but pale and living beneath the glass.

“Is it ground?” he asked.

“Almost,” Jack said.

The clock laughed. Its case split. A young man’s ghost stepped out and vanished through the wall like smoke.

All around them, the house released its dead.

They poured from bells and carvings, from the grain of wooden doors, from mirrors clouded with old breath. Some wore clothes from Jack’s grandfather’s time; others were ancient enough to carry swords of bronze. They moved toward the foundations, their faces turned downward to the earth.

The maintenance door burst open onto the garden.

The moor was close enough for Jack to see individual stones.

The beanstalk no longer stretched straight down. It bowed beneath the descending house, its lower trunk rooted beside the cottage and its upper branches thrashing through the garden. Jack seized it. Nell clipped their harnesses to the same stem. The goose tucked herself beneath Nell’s arm and objected violently.

They descended as the house descended around them.

Above, Lord Morrow came over the garden wall.

He stepped onto the beanstalk.

The living road bent beneath his weight but did not break. He climbed after them, copper beard whipping in the storm. Lady Morrow stood at the wall behind him, one hand braced against the house, shouting commands to machinery that no longer recognized her alone.

“John Alder!” Lord Morrow called.

The vine tightened around Jack’s ankle at the sound of his name.

“Nell Arun!”

Leaves closed over Nell’s hands.

The harp played a single furious note. The vine released them.

“Names are histories,” it sang. “Not chains.”

The ground rushed nearer.

Jack saw his mother at the foot of the stalk, axe in hand. Around her stood half the village. Behind them, the cloud-house blotted out the stars, its towers breaking free of vapor, its windows blazing. It was no longer falling. It was being lowered, foot by measured foot, every tilt answered by the anchor crews.

“Not yet!” Jack’s mother shouted as someone raised a blade toward the beanstalk. “It is still carrying them!”

The black foundations touched the moor.

The impact traveled through the earth as a deep, rolling boom. Water jumped from wells. Roof tiles rattled. Jack lost his grip and slid the last twelve feet into his mother’s arms, knocking them both flat.

Nell landed beside them in a heap of rope, goose, and profanity.

Lord Morrow remained twenty feet above the ground.

He looked down at the villagers.

For the first time in fifty years, a giant looked neither downward from a cloud nor outward from an unreachable window. He looked into the faces of the people whose possessions fastened his coat.

He began to descend.

Jack’s mother rose, took the axe in both hands, and struck the beanstalk.

Sap burst from the wound, green and brilliant. Jack took the axe from her and struck again. Nell’s uncle struck third. Then farmers, laundresses, masons, weavers, and children old enough to lift a blade crowded around the trunk.

The beanstalk split.

Lord Morrow jumped.

He hit the wet earth hard enough to leave two deep prints but remained standing. Behind him, the severed vine tore free of the cloud-house. Its upper length whipped into the storm like a living rope, scattering leaves across the valley. The lower trunk fell across the fields with a sound like a forest collapsing. It crushed three fences, one empty shed, and Mr. Pike’s least successful row of onions.

The house did not fall.

It stood upon the moor under the rain, black and vast and impossible, exactly as it had stood in the sky—except that its doors were now level with common earth.

The harp began to sing.

Its voice passed from the tuning peg to the anchors, from the anchors into every bell in the valley, and from the bells into the house itself. It named each coin, each cup, each acre of rain. It named the dead. It named the living. It named Wren’s unpaid measure of gold and Ada’s nine final days. It named the silver brooch Jack’s mother had sold and the golden egg that held it.

The great doors of the house opened.

Behind them, the treasury shone.

Lord and Lady Morrow stood before their own records, surrounded by hundreds of people holding axes, ledgers, wash poles, kitchen knives, blacksmith’s hammers, and five iron keys removed from five released anchors.

They were still giants.

They were still dangerous.

But they were no longer gods.

* * *

It took seven days to make the settlement and most of a winter to carry it out.

The Morrows surrendered the gold eggs, the tax records, the weather jars, and every object the harp identified as seized beyond the old covenant measure. In return, the villagers did not burn the house, imprison the giants in their own walls, or send word to the mountain clans that giant opals were fetching an excellent price in the north.

Lady Morrow argued every clause. Lord Morrow argued every noun. Jack’s mother sat across from them at a table built hastily on the moor, wearing her cleanest dress. Each time a Morrow challenged a term, she found the matching line in their ledger and pushed it back across the table. Nell’s uncle advised her on mechanisms. Wren advised her on magic. The harp corrected everyone.

The weather key was placed under five locks, one for each district of the valley. No rain could be held, sold, or released unless three districts agreed. The cloud itself unraveled slowly from the house and returned to the ordinary sky. For the first time in Jack’s life, weather came to Bellweather without permission.

The goose, once freed of her collar, never laid gold again.

She laid ordinary warm brown eggs in Wren’s empty byre, terrorized his turnips, and bit him whenever he attempted to discuss machinery in her presence. Nell named her Majesty. The goose refused the name but answered to it reliably.

Dapple came home on the first clear morning.

Wren led her down the muddy lane with a sack of turnip tops tied to her back. Jack’s mother stood in the doorway, arms folded.

“She was part of the bargain,” Wren said.

“The bargain was made with property that did not belong solely to him.”

Wren glanced at Jack. “I have learned not to argue contracts with your mother.”

“It took a giant house falling from the sky,” Jack said, “but people can improve.”

His mother gave him a look.

Dapple thrust past them into the lean-to and began eating as if she had been gone five minutes.

Some of the returned gold was set aside for the winter levy. Then the settlement abolished the levy, so the money paid for roof thatch, seed grain, a new copper preserving pan, and the medicine of everyone who needed it. Nell’s uncle kept his workshop. Mrs. Fen paid for her washing. Jack’s mother never moved to her sister’s village, although she did take the coach there in spring simply because, for once, she could afford to.

The cloud-house remained on the moor.

Without vapor hiding its lower stories, it appeared larger than anyone had imagined. Its towers caught the evening sun. Rain ran in the proper direction along its gutters. Some windows still looked onto other seasons, and the thunder tree continued to bloom in its walled garden. The released spirits left the clocks and doors one by one, walking into the fields until they faded beneath the open sky.

The Morrows lived there under the terms of the settlement. They did not become kind. Jack thought that would have been less believable than the beans. But they became answerable, which was a beginning.

Late that winter, Jack sat with his mother on the repaired cottage roof. They had climbed up to replace a loose patch of thatch before the next storm. The sky above Bellweather was enormous without the cloud. Stars filled the space where the house had been.

Across the dark fields, lights burned in the windows on the moor.

His mother tied off the thatch and tested the knot.

“You sold my cow,” she said.

Jack looked at her. “I got her back.”

“That does not improve the decision you made at the time.”

“No.”

“You climbed after I ordered you down.”

“I remember.”

“I am still angry.”

“I know.”

She was quiet. Wind moved through the bare pear branches. Far off, the giant house gave one deep midnight chime, now no louder than any other bell carried across the valley.

His mother put an arm around his shoulders and drew him against her side.

“I am also proud of you,” she said. “It is extremely inconvenient.”

Jack leaned his head against hers.

The next weather was coming over the western hills. He could smell snow in it—cold stone, distant pine, the clean mineral scent of the air before the first flake falls. Nothing held it back. Nothing measured it. Above the black fields, the stars vanished one by one as the clouds came on.

Jack watched them come.
