---
id: "jack-ch-07-after-fall-summary"
chapter_id: "jack-ch-07-after-fall"
pov: "Jack"
characters:
  - "Jack"
  - "Nell"
  - "Jack's Mother"
  - "Lord Morrow"
  - "Lady Morrow"
  - "Majesty"
  - "The Harp"
  - "Silas Wren"
  - "Dapple"
beats:
  - "The five valley crews lower the cloud-house while the Morrows fight for control."
  - "The house reaches the moor and the villagers cut down the beanstalk."
  - "The harp identifies what was stolen, forcing a settlement that returns weather and wealth to Bellweather."
spoilers_ok: true
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
As the anchor crews lower the cloud-house, Jack and Nell struggle against the Morrows and the failing machinery. The house spirits, the harp, and the liberated goose help them survive until the estate reaches the moor. Bellweather’s people cut the beanstalk, confront the giants on common ground, and use the harp’s testimony to recover what was taken. The settlement makes weather a shared responsibility, returns Dapple and the valley’s wealth, and leaves the Morrows answerable rather than untouchable.