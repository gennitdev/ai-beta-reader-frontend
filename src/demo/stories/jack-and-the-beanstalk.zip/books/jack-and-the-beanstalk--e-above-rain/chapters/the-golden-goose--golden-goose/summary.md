---
id: "jack-ch-06-golden-goose-summary"
chapter_id: "jack-ch-06-golden-goose"
pov: "Jack"
characters:
  - "Jack"
  - "Nell"
  - "Jack's Mother"
  - "Silas Wren"
  - "Lady Morrow"
  - "Majesty"
  - "The Harp"
beats:
  - "Bellweather prepares five anchor crews while Jack and Nell return to the cloud-house."
  - "The children free the goose and reach the weather room with the harp’s help."
  - "A final golden egg damages the regulator and lets them turn the weather key."
spoilers_ok: true
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
The village organizes crews at all five anchors while Jack and Nell climb through a violent storm for a second time. Inside, they follow the rebellious house spirits to the treasury, free the goose from the machinery locked around her throat, and race to the weather room. The goose expels one final immense golden egg, damaging the regulator long enough for the children to turn the weather key and signal the valley below.