---
id: "jack-ch-06-golden-goose"
book_id: "jack-house-above-rain"
part_id: "jack-part-03-bring-down-house"
title: "The Golden Goose"
cover_image_id: "jack-asset-06-goose"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
wiki_mentions:
  - id: "jack-ch-06-golden-goose-mention-jack"
    wiki_page_id: "jack-wiki-jack"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-nell"
    wiki_page_id: "jack-wiki-nell"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-mother"
    wiki_page_id: "jack-wiki-jacks-mother"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-wren"
    wiki_page_id: "jack-wiki-silas-wren"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-lady-morrow"
    wiki_page_id: "jack-wiki-lady-morrow"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-majesty"
    wiki_page_id: "jack-wiki-majesty"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-harp"
    wiki_page_id: "jack-wiki-truth-harp"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-bellweather"
    wiki_page_id: "jack-wiki-bellweather-valley"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-cloud-house"
    wiki_page_id: "jack-wiki-cloud-house"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-06-golden-goose-mention-weather-room"
    wiki_page_id: "jack-wiki-weather-room"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
---
They argued until morning.

Jack’s mother did not change her answer. Wren could draw a map. Someone else could climb. The village had roofers, steeple workers, men who harvested pears from ladders twice Jack’s height.

But the house had smelled Jack and Nell. The maintenance passages had admitted them and the harp had chosen to help them. Wren’s old brass mark would open the weather room only when carried by someone the house had already accepted as maintenance. It was an absurd distinction, and the house was built out of absurd distinctions.

His mother volunteered to go with them.

Wren refused. Someone had to command the anchor crews and hear the harp’s timing through the tuning peg. No one else understood, as she now did, that lowering the house was not one action but a continuous balancing of five. If the western line ran too quickly, the tower district would break away. If the south held too long, the foundations would roll over the village.

In the end, she did not give Jack permission so much as acknowledge that no remaining choice was safe.

“I am not agreeing because you were brave,” she told him. “I am agreeing because you have already been inside, because the house will open for you, and because sending someone else ignorant of it may kill us all. Do you understand?”

Jack nodded.

“Say it.”

“You still think I shouldn’t have climbed.”

“I think I may remain angry about that until I die.”

She spent the morning preparing them.

From laundry rope and strips of sailcloth she made climbing harnesses that fit close around their legs and ribs. She lined their coats with pieces cut from his father’s blanket. She packed bread, hard cheese, two onions, candles, flint, bandages, a flask of hot tea, and the small kitchen knife because it was the sharpest blade they owned. She tied each object into the satchels so nothing could fall. Her hands never stopped. When a knot slipped, she swore and tied it again.

Meanwhile, the harp’s tuning peg sang the truth of the Morrows’ taxes in the village square.

People came carrying hammers, crowbars, mattocks, ropes, and old grievances. Nell’s uncle brought the iron tools with which he had once repaired the northern anchor’s gate, and five tuning forks from the drawer where he kept the things nobody had ever asked him to mend. Wren struck each fork against the harp’s peg until it held the note. One would stand at every anchor stone, so that the crews could hear the harp’s timing and the harp could hear them. Mrs. Fen came with six washing women, all of whom knew how to lower a boiler without crushing anyone beneath it. Farmers arrived from the outer valley before noon. By dusk, five crews waited at five stones.

The Morrows’ cloud darkened above them.

Rain began to fall around its edges, forming a wall that hid the hills.

Wren gave Jack his brass ring.

“The weather room lies behind the treasury,” he said. “The key is mounted in the central regulator. Turn it until the opal points down. Not left. Not right. Down.”

“And the harp?”

“Bring it out if you can. With it, they cannot deny what they have taken.”

“The goose too,” Nell said.

Wren glanced at her. “The goose is machinery. The final lock on her collar answers to the weather key and to nothing else. The Morrows made certain their gold could never leave the house while the house remained in the sky.”

“The goose is a goose with machinery locked around her throat.”

Nell’s uncle looked proud.

At the base of the beanstalk, Jack’s mother tightened the final knot on his harness. Her face was composed now. That frightened him more than her shouting had.

“Come back,” she said.

“I will.”

“Do not promise me what you cannot control.”

Jack swallowed. “I will do everything I can.”

She pulled him against her and held him hard. Then she released him, checked Nell’s rope, and slapped the stalk with her palm.

“Go,” she said.

They climbed into the rain.

* * *

Night came while they were inside the cloud.

The storm turned the beanstalk into a black moving world. Rain drove sideways. The wind tore words from their mouths, so Jack and Nell communicated by pulls on the rope: one for stop, two for climb, three for trouble. Lightning made the leaves transparent around them. Through their green flesh Jack saw branching veins and small luminous creatures swimming in the sap.

Above the weather, moonlight lay over the cloud.

The house stood black against the stars. Most of its windows were lit. The copper pipes along its walls pulsed blue, and from somewhere inside came the slow tolling of a clock.

The garden was waiting for them.

The rain lilies had closed. The hail-plums turned on their stems as Jack passed, following the warmth of his body. Beneath the thunder tree stood Lady Morrow.

Or something shaped like her.

It was made from fog and moonlight, translucent as breath on glass. When Jack stopped, it opened its amber eyes.

“John Alder,” it said.

The harp had begun that sentence in the treasury, and Jack had stopped it before the name. It had not mattered. The house had heard the coat, the mother, the father, and the son, and it had needed nothing more to finish the sum.

The sound of his full name struck the house like a key entering a lock.

Every window brightened.

Nell shoved Jack through the little door. The mist-image reached for them and came apart against the threshold, pouring through the cracks as white vapor.

Inside the maintenance passage, doors began to slam one after another.

“It knows you,” Nell said.

“You noticed.”

“I am trying to be supportive under pressure.”

The tuning peg vibrated inside her coat. She took it out. A thread of silver light stretched from it into the wall, pointing the way.

They ran.

The house tried to turn them aside. One door opened onto Jack’s kitchen at home, warm and golden, his mother standing at the table with Dapple’s milk steaming in a jug. Jack had taken one step toward it before he saw that his mother’s shadow faced the wrong direction.

Nell yanked him back. The door bit at her sleeve when she closed it.

Another passage filled with summer grass. His father stood at its far end, broad-shouldered in the coat from which Jack’s had later been cut.

“You’ve grown,” he said.

Jack shut that door himself.

Nell’s temptations were quieter. Once she stopped before a window in the wall. Through it Jack saw her uncle’s workshop, every drawer labeled, every brass tool in its place. A line of customers waited outside with money in their hands. Nell stared until Jack took her wrist.

“Not real,” he said.

“I know.” Her voice was rough. “It arranged the screwdrivers by size. My uncle has never done that in his life.”

They followed the tuning peg into the treasury.

The goose was still in her cage. More gold showed beneath the thin skin of her beak. She lifted her head when Nell approached and struck the bars with such fury that the locks rang.

“Good evening,” Nell said. “I see captivity has improved your disposition.”

She unrolled her tools.

Jack climbed the leg of the writing desk to reach the harp. The instrument watched him in its own fashion, strings tightening and loosening as he approached.

“John Alder,” it sang.

“Yes, yes. Everyone knows now. You saw to that.”

“I named a coat,” the harp said. “The house named you. I cannot help what a ledger does with a true entry.”

“Son of Thomas Alder and Alice Vale Alder. Debtor by levy, trespasser by statute, claimant by injury.”

“Will you come with us?”

The harp considered. A minor chord moved through its strings.

“Ownership disputed.”

“We aren’t claiming to own you.”

“Then define removal.”

Below, one of the goose’s locks clicked open.

Nell looked up. “We need you to testify where everyone can hear you. After that, you can go wherever you like.”

The harp played a questioning phrase.

“Yes,” Jack said. “Even if it isn’t with us.”

The strings softened.

“Terms accepted.”

Jack strapped the harp to his back. It weighed less than he expected, though its curved pillar rose awkwardly above his shoulder.

Nell opened the sixth lock.

The seventh had no keyhole.

It was a smooth circle of black iron at the front of the collar, stamped with Lord Morrow’s seal. Gold pulsed beneath it in time with the goose’s heart.

The harp plucked a low note.

“Final lock,” it sang. “Bound to weather key.”

“Then she comes with us that far,” Nell said.

She opened the cage.

The goose exploded out of it.

Her wings struck Nell in the face. She bit Jack’s knee, flapped onto the writing desk, knocked over an ink jar, and hissed at the harp.

“I respect her spirit,” Nell said, wiping blood from her lip.

A door opened across the treasury.

Lady Morrow stooped beneath its arch.

She had exchanged her storm-colored gown for a coat of overlapping silver plates. Her pale hair hung loose. In one hand she carried no club or carving knife, but a slender black wand engraved from end to end with names.

“John Alder,” she said.

The walls tightened around Jack.

Plaster flowed over the maintenance doors. The floorboards bent upward at their edges like the sides of a closing book.

“Nell Arun,” Lady Morrow said.

Nell gasped. The tools lifted from her hands and flew into the giant’s palm.

“You confuse knowing a name with owning it,” the harp sang.

Lady Morrow drew the naming wand across her palm. The engraved names lit one after another.

“You were not asked.”

“Harp of Rowan Court,” the instrument answered. “Taken by penalty following unauthorized sunshine. Ownership disputed.”

Every golden egg in the treasury began to hum.

Jack seized Nell’s hand. The goose charged through the nearest opening, and they ran after her.

Lady Morrow’s wand struck the floor behind them.

Names spilled from it in black threads. They crawled along the boards and up the walls: the names of villagers, workmen, thieves, debtors, people long dead and people trapped in clocks. Wherever a name touched wood, a face opened its eyes.

The harp struck a chord.

“Weather room,” it sang, and a sealed arch burst open.

Jack, Nell, and the goose plunged through.

The center of the house was full of sky.

The weather room formed a vast circle beneath a glass dome. No floor crossed its middle. Instead, Bellweather Valley appeared below them in perfect miniature—not a model but the valley itself, seen through a column of transparent air. Jack saw anchor fires burning at five points in the darkness. He saw the beanstalk laid across the distance between earth and cloud like a green thread.

Around the open shaft turned wheels of iron and opal. Copper pipes entered the walls in every direction. Rain ran upward through some; sunlight flowed like molten gold through others. At the center of the machinery stood the weather key.

It was taller than Jack and shaped like a five-branched star. Its iron shaft passed through a regulator marked with symbols for wind, weight, rain, and height. The opal in its center pointed toward the ceiling.

“Down,” Jack said.

The key did not move when he pushed it. Nell joined him. Together they strained until their boots slid on the copper platform.

Lady Morrow entered the room.

“You believe this house is held up by a key?” she asked. “It is held up by agreements. By measures and covenants, labor and law. Things children cannot understand because children believe unfairness invalidates a contract.”

The black threads of the naming wand spread across the platform behind her.

Jack pushed harder. “Did the barley agree not to have rain?”

“The valley accepted our management.”

“The valley was afraid of you.”

“Fear is among the oldest forms of acceptance.”

The goose hissed and hurled herself at the key. Her beak struck the opal.

The final lock on her collar opened.

Gold light burst through the room.

The collar fell in two pieces. For a moment the goose stood surrounded by a shining outline of every object ever fed into her: rings, spoons, coins, cups, buckles, brooches, all turning through her body in a bright storm. Then she spread her wings.

The accumulated gold came out at once.

A golden egg larger than a millstone struck the platform, rolled between Jack and Nell, and crashed into the regulator. Lady Morrow sprang aside as it came on; her wand slipped from her hand and vanished into the open shaft. The machinery jumped. The weather key lurched a quarter turn.

“Now!” cried the harp.

Jack and Nell threw their weight against the branches, and the key turned from sky toward horizon.

The harp began to sing.

Its note traveled down the copper pipes, through the beanstalk, and into the five anchor stones. Far below, five tuning forks answered.

At the western anchor, Jack’s mother raised her hand.

“Release one measure!” she shouted.

Five crews leaned into five iron wheels.
