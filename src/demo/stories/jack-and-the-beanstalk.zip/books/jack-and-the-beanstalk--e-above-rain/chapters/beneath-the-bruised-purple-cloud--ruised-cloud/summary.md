---
id: "jack-ch-01-bruised-cloud-summary"
chapter_id: "jack-ch-01-bruised-cloud"
pov: "Jack"
characters:
  - "Jack"
  - "Jack's Mother"
  - "Nell"
  - "Silas Wren"
  - "Dapple"
beats:
  - "The giants impose another rain levy on struggling Bellweather Valley."
  - "Jack and his mother decide that Dapple must be sold so they can survive the winter."
  - "Silas Wren trades Jack three magical beans and a claim against the Morrows for Dapple."
spoilers_ok: true
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
A punishing rain levy leaves Jack and his mother with no choice but to sell their cow, Dapple. On the road to market, Jack and Nell meet the grieving artificer Silas Wren, who reveals that he built the giants’ cloud-house and was never fully paid. Jack accepts Wren’s last three maintenance-road beans in exchange for Dapple, hoping the road they grow will lead to the wealth taken from Bellweather Valley.