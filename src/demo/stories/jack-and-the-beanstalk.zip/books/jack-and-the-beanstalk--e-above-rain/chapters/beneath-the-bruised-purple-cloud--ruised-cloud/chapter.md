---
id: "jack-ch-01-bruised-cloud"
book_id: "jack-house-above-rain"
part_id: "jack-part-01-bargain"
title: "Beneath the Bruised Purple Cloud"
cover_image_id: "jack-asset-01-cloud"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
wiki_mentions:
  - id: "jack-ch-01-bruised-cloud-mention-jack"
    wiki_page_id: "jack-wiki-jack"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-01-bruised-cloud-mention-mother"
    wiki_page_id: "jack-wiki-jacks-mother"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-01-bruised-cloud-mention-nell"
    wiki_page_id: "jack-wiki-nell"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-01-bruised-cloud-mention-wren"
    wiki_page_id: "jack-wiki-silas-wren"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-01-bruised-cloud-mention-dapple"
    wiki_page_id: "jack-wiki-dapple"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-01-bruised-cloud-mention-bellweather"
    wiki_page_id: "jack-wiki-bellweather-valley"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-01-bruised-cloud-mention-wren-house"
    wiki_page_id: "jack-wiki-wrens-house"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-01-bruised-cloud-mention-cloud-house"
    wiki_page_id: "jack-wiki-cloud-house"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
---
The cloud had hung above Bellweather Valley longer than Jack had been alive.

It was not like the loose white clouds that came shouldering over the western hills in spring, shedding bright curtains of rain and leaving shadows running over the fields. This cloud never traveled. It stood above the valley in every season: green-black in summer, iron-gray in winter, bruised purple when lightning moved inside it. Sometimes, on a very clear evening, its lower vapors thinned, and people looking up from the fields could glimpse the foundations of the house within—the black angles of its stone, the green flash of a copper gutter, a window burning gold at a height where no window had any business being.

The giants lived there.

Jack had known that before he knew why frost silvered the grass or why his father’s boots still stood beside the cottage door three years after there was no one left who could wear them. The giants owned the cloud, and the cloud owned the weather, and therefore, as Lord and Lady Morrow’s proclamations frequently explained, the giants owned a portion of everything the weather made.

That autumn, the barley had come up thin and gray. Rain had passed over the valley in sight of every farmer and had fallen, silver and abundant, upon the hills beyond it. Then, after the grain was cut and there was nothing left for the water to save, the giants released three days of rain at once. The lanes dissolved. Potatoes rotted in their furrows. Brown water stood in the lower fields with drowned mice floating in it like scraps of wet fur.

On the morning the tax bell rang, Jack was in the ash wood gathering fallen branches.

He heard the first note through the trees: a vast bronze sound that seemed to enter his chest without passing through his ears. Rooks burst out of the bare crowns. Drops of yesterday’s rain shook loose and pattered on his shoulders. Jack straightened slowly, one hand around a branch, and looked toward the cloud.

A black speck had appeared beneath it.

The speck descended until it became an iron cylinder as long as a farm cart, hanging from a chain that vanished into the vapor. It passed over the river and the church spire and came to rest in the village square. The second stroke of the bell followed it down.

Jack tucked the branches under his arm and ran.

He was fourteen and had grown badly that year, as his mother put it, all at once and without consideration for his clothes. His wrists stuck out of his coat sleeves; his boots pinched at the toes and gaped at the ankles. The wind came knifing across the fields, lifting the coat away from his ribs, and he ran with his chin tucked down and the wet branches clutched against him.

By the time he reached the cottage, the villagers were already streaming back from the square with the proclamation.

Their house crouched at the end of a muddy track, its limewash worn away beneath the windows and its thatch patched with pieces of feed sack tied under the eaves. The pear tree had not borne fruit in two years. His mother had dug the garden all the way to the privy wall and planted turnips wherever there was room between the stones. Now the turnip leaves lay flattened in the mud, their pale undersides shining.

Inside, the cottage smelled of damp wool, woodsmoke, lye soap, and apples beginning to scorch.

His mother stood at the table pressing circles of pastry over spoonfuls of stewed apple. She made the pastry with more water than butter and rolled it thin enough for light to pass through. Three finished hand pies waited on the board. She would carry them to the inn at noon, where the keeper might buy them if his wife had not baked that day.

Everything else she did to keep them alive crowded the room around her. A spinning wheel stood before the cold half of the hearth, a strand of coarse brown wool still drawn through the flyer. Shirts belonging to other families hung from a line overhead, ghostly in the smoke, never quite drying. Two baskets of mending waited beneath the bench. A blue dress lay soaking in lye water near the door. The skin across her knuckles was cracked and angry from washing, and there was a small white burn on her wrist from the oven.

She looked up when Jack entered. His mother was not old—thirty-nine, she had told him sharply the last time he guessed—but the past three years had put gray into the dark hair at her temples and fine lines between her brows. She was a handsome woman still, straight-backed and broad-shouldered, with hazel eyes that could warm a room when she laughed. Jack had not heard her laugh much that autumn.

“The winter levy,” he said.

“I heard.” She sealed the edge of a pie with her thumb. “One-sixth more.”

“For what?”

“Management of the rain.”

Jack looked toward the window. Beyond its wavery green glass, rainwater still dripped from the eaves into a yard deep in mud.

His mother followed his gaze. “Yes,” she said. “Apparently drowning the potatoes was expensive.”

Something bumped the outside wall. Their cow, Dapple, lowed from the lean-to, a hoarse, reproachful sound. She had given scarcely a cup of milk that morning. There was not enough hay to keep her through winter, and they both knew it.

Jack set the wood beside the hearth. “Mrs. Fen says she’ll pay for the washing next week.”

“Mrs. Fen said that last week.”

“I could ask Mr. Pike for more work.”

“Mr. Pike pays you in onions.”

“They’re good onions.”

“They are excellent onions. The ferryman remains stubbornly unwilling to accept them as passage money.”

She said it lightly, but her fingers had stopped moving. For three months she had been trying to save enough to take them north to her sister’s village before snow closed the pass. Her sister had a small house, five children, and, most importantly, no cloud above her fields. There would be work for Jack in the slate yard and laundry for his mother from the boardinghouse. They did not need a fortune. They needed the tax debt paid and two seats on the winter coach.

They had sold the copper preserving pan. They had sold Jack’s father’s good saw and the little silver brooch his mother used to wear on Sundays. She had spun by firelight until her hands cramped shut, washed sheets in water that skinned her fingers red, baked pies, mended trousers, weeded other people’s gardens, and sat up with sick children for whatever their parents could spare. The sum in the blue crock above the hearth had risen painfully, coin by coin.

The new levy took almost all of it.

His mother wiped flour from her hands. “Dapple must go to market.”

The cow bumped the wall again, as if she had heard.

Jack had known this was coming. Even so, the words seemed to alter the cottage. Dapple had been born the spring before his father died. Jack had slept in the byre the night she came, wrapped in a horse blanket, waking each time the calf stirred in the straw. She was brindled brown and cream, with one crooked horn and long lashes the color of honey.

“Mr. Bell will cheat us,” he said.

“Mr. Bell cheats everyone. That makes it a market rate.” His mother crossed to the blue crock and counted out three pennies. “Take Nell with you. She knows when a butcher is lying.”

“Nell thinks everyone is lying.”

“Which is why she is so seldom disappointed.”

She put the pennies into his hand for the market toll and closed his fingers around them. Her palm was rough and hot from the oven.

“Get what you can,” she said. “But get money, Jack. Not a promissory note. Not a lame goat. Not a clock someone swears only needs winding. Money.”

He managed half a smile. “I know what money looks like.”

“Bring some home and we shall both admire it.”

Then she went into the lean-to to say goodbye to the cow where Jack could not see her face.

* * *

Nell was waiting at the north milestone in her uncle’s blue coat, which was too wide in the shoulders and reached nearly to her boots. She was fifteen, short and solidly made, with brown skin, black hair braided tight against the weather, and a pale notch through her left eyebrow from the time a roof tile had objected to being repaired. Her uncle mended locks, watches, mill gears, and anything else with small resentful parts. Nell had inherited his hands and none of his patience.

She inspected Dapple’s teeth, hooves, eyes, and udder before they set out.

“Twelve crowns,” she said.

“Mr. Bell won’t give twelve.”

“Then we shall insult him until he gives ten.”

“Mam says we mustn’t be thrown out of another market.”

“Your mother worries too much.”

“You told her Mr. Bell’s face looked like a boiled ham.”

“It does. I can’t be held responsible for the shape of a man’s face.”

They walked north with Dapple’s rope between them. The rain had stopped, but water hissed in the roadside ditches and a low mist lay across the fields. Bare hawthorn scratched at the sky. Here and there, the sun broke through the moving weather and lit the wet grass so fiercely that every blade seemed edged with glass. Above it all, the giants’ cloud remained fixed, its underside dark as old iron.

They had gone two miles when Dapple stopped before a gate Jack had never noticed.

The gate leaned between two alders, almost lost beneath ivy. Beyond it, a narrow path wandered uphill to a small stone house. Once it might have been yellow. Now moss covered the roof, nettles stood in the garden, and the upper windows reflected the cloud.

An old man sat beside the path in a chair made from a barrel. At his feet was a new grave.

The earth had been heaped carefully and covered with late purple asters to keep the rain from beating it flat. A pair of spectacles rested on the stone at its head. The old man was looking at them when Dapple lowed.

He raised his face.

He had a long, colorless beard, a nose like the blade of a trowel, and blue eyes clouded at the rims. His coat had once been green velvet, though weather and years had reduced it to the color of pond water. On one hand he wore a heavy brass ring engraved with three leaves twisting around a tower.

“That cow has good sense,” he said. “More than most travelers. She has stopped before the rain.”

Jack looked up. A hard silver shower was crossing the valley toward them.

“We’re going to market,” Nell said.

“So is everyone who possesses something they would rather keep.” The old man studied Dapple. “How much?”

“Twelve crowns,” Nell said promptly.

“Ten,” Jack said at the same time.

Nell turned on him. “I was beginning a negotiation.”

“You concluded it very quickly,” said the old man.

Rain struck the leaves behind them with a rising roar. He beckoned them toward the house.

Inside, it was warm and smelled of dust, rosemary, and something metallic beneath both. Books lay in towers on the floor. Copper models of planets turned slowly beneath the ceiling although there was no draft. On the table stood six brown medicine bottles, all empty, and beside them a bowl holding three beans.

Jack noticed the beans because they were the only clean things in the room. Each was as large as the end of his thumb, deep green marbled with silver, as if moonlight had worked its way beneath the skin.

The old man noticed him noticing.

“Silas Wren,” he said. “Former artificer of weather, suspension, and architectural impossibilities. Present keeper of an excellent supply of turnips and an empty byre.” He looked at the grave through the rain-streaked window. “My wife liked milk in her tea.”

Nell did not take off her coat. “If you want the cow, you can pay for her.”

“I can.” Wren touched one of the beans with the tip of a yellow nail. “But not in coin.”

“Then you can’t,” said Jack.

“Good,” Nell said. “He does know what money is.”

Wren almost smiled. Then he picked up the bowl and held it beneath the turning planets.

“Fifty-one years ago,” he said, “Lord and Lady Morrow hired me to raise their estate above Bellweather Valley. The hill they owned was too damp, the neighboring roads were too public, and they preferred a view. I built five anchors in the earth and a weather engine in the house. Between them I strung a suspension field strong enough to lift seventy thousand tons of stone, timber, copper, furniture, livestock, and giant.”

Jack stared at the brass ring. He had seen the three leaves and tower before. It was stamped into the iron tax cylinders and carved above every anchor stone in the valley.

Wren followed his gaze. “Yes.”

“You made the cloud fly.”

“The cloud is condensed around the machinery. Clouds do not fly, boy. They are carried by moving air.”

Nell leaned toward Jack. “He has been waiting fifty years to correct someone about that.”

“Forty-nine,” Wren said. “During the first two, people knew better.”

He lifted one bean out of the bowl and set it on his palm. When he breathed across it, the silver veins brightened. A root no thicker than a hair pushed through the skin. It curled around his finger, sprouted two leaves, and lifted its head toward the ceiling. Within seconds the vine was as long as Jack’s arm. Wren pinched it. The growth stopped.

“Maintenance roads,” he said. “Living ladders capable of finding the magic they were grown to reach. I kept the last seeds.”

The rain rattled against the panes. Dapple shifted in the shed at the back of the house, where Wren had led her out of the storm.

“The Morrows promised me three measures of giant gold,” he continued. “They paid two. My wife, Ada, persuaded me to accept the loss rather than spend the remainder of my life quarreling with creatures who could store my house in a cupboard. For many years, I thought her wise.”

His gaze moved to the empty bottles.

“This summer the Morrows doubled the apothecary’s levy. Last month I sold the final ounce of their gold for Ada’s medicine. It bought nine days.”

For a moment the only sound was the rain.

Jack thought of his mother’s hands, the white burn on her wrist, the pennies in the blue crock. He thought of the proclamation hanging in the square and of water falling on empty hills while their barley withered.

“What do the beans do?” he asked, though Wren had told him.

“They will take you to the house.”

“And then?” Nell said.

“Then you may see what became of Bellweather’s missing wealth.”

Wren went to a cabinet and brought out a leather roll. Inside was a set of yellowing plans, covered with measurements and close black writing. Jack recognized the outline of the cloud-house: foundations, towers, pipes, a great circular room at its center. At the bottom was Lord Morrow’s seal and a promise of payment in three measures. Beneath that, in smaller writing, was a receipt for two.

“Why don’t you go?” Jack asked.

Wren tapped his chest. “My heart objects when I climb the stairs. I doubt it would improve at ten thousand feet.”

“So you want us to rob the giants for you.” Nell folded her arms. “In return for our cow.”

“I am offering a road and a rightful claim. What you do with either is your affair. Bring me what I am owed, and the rest of anything you recover is yours.”

“Anything?”

“The Morrows own objects worth more than this valley has produced in a hundred years.”

Nell examined the plans, the ring, the live curl of vine around Wren’s finger. Her expression had changed. Her uncle’s workshop had been assessed for unpaid rain tax three weeks ago. At Midwinter, if he could not pay, it would become the property of the cloud.

Jack knew what his mother would say. He could hear each word in her voice: *Money, Jack. Not a promissory note. Not a lame goat. Not a clock.*

But these were not beans from a roadside peddler. The cloud existed. The plans existed. Wren’s mark was cut into stones Jack had climbed on since childhood. Above them, immense and dark, stood a house full of the valley’s money.

He looked through the back door. Dapple had found a manger of turnip tops and was eating with the absolute concentration she gave to all important matters.

“You’ll keep her through winter?” he asked.

“Better than a butcher will.”

Nell caught his sleeve. “Jack.”

“You believe him.”

“That is not the same as believing this is a good idea.”

“It could pay the tax. It could pay for the coach. It could save your uncle’s shop.”

“It could get us put in a cupboard.”

Wren said nothing. Jack wished he would. He wished the old man would make a claim so extravagant that the decision became easy.

Outside, the cloud swallowed the last of the sun. The room dimmed. One of the copper planets turned, and a tiny blue spark passed soundlessly between it and the moon.

Jack held out his hand.

“The beans,” he said.