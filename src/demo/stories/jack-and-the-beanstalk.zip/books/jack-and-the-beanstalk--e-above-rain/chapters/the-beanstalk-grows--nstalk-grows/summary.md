---
id: "jack-ch-03-beanstalk-grows-summary"
chapter_id: "jack-ch-03-beanstalk-grows"
pov: "Jack"
characters:
  - "Jack"
  - "Jack's Mother"
  - "Nell"
beats:
  - "The beanstalk grows from the cottage garden into the giants’ cloud."
  - "Jack and Nell prepare to investigate before the Morrows discover the living road."
  - "They climb through wind and rain toward the cloud-house."
spoilers_ok: true
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
By morning, the magical vines have braided themselves into an enormous beanstalk reaching the stationary cloud. Although Jack’s mother forbids the climb, Jack and Nell fear the Morrows will destroy the road if they wait. They begin climbing with provisions and a rope between them, leaving the valley—and Jack’s furious, frightened mother—far below.