---
id: "jack-ch-03-beanstalk-grows"
book_id: "jack-house-above-rain"
part_id: "jack-part-02-above-rain"
title: "The Beanstalk Grows"
cover_image_id: "jack-asset-03-beanstalk"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
wiki_mentions:
  - id: "jack-ch-03-beanstalk-grows-mention-jack"
    wiki_page_id: "jack-wiki-jack"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-03-beanstalk-grows-mention-mother"
    wiki_page_id: "jack-wiki-jacks-mother"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-03-beanstalk-grows-mention-nell"
    wiki_page_id: "jack-wiki-nell"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-03-beanstalk-grows-mention-bellweather"
    wiki_page_id: "jack-wiki-bellweather-valley"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-03-beanstalk-grows-mention-cottage"
    wiki_page_id: "jack-wiki-jacks-cottage"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-03-beanstalk-grows-mention-cloud-house"
    wiki_page_id: "jack-wiki-cloud-house"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
---
By sunrise, half the village stood in the lane.

Children splashed beneath the leaves. Chickens pecked at luminous green crumbs of earth. Men prodded the lowest stalk with spades and drew back when it flexed beneath their hands. The plant smelled of cut grass, cold stone, and the sweet green scent inside a pea pod.

Jack’s mother stood in the garden in her work dress and shawl, staring upward. She had not spoken to him except to order him away from the roots.

The beanstalk had grown through the lower branches of the pear tree, lifting them without breaking them. Its main trunk was wider than the cottage chimney. The braided stems formed hollows and ledges all along its surface, and the leaf stalks sprang out at intervals like the rungs of an immense ladder.

“It appears,” Jack said carefully, “that he told the truth about the beans.”

His mother turned her head.

“It being magic does not make it money.”

That ended the conversation.

Silas Wren was not among the villagers. Jack’s mother sent Mr. Pike’s eldest son to fetch him, with instructions to bring the old man by the collar if necessary. Then she went inside to change her mud-soaked shoes.

Nell stepped out from behind the pear tree.

She wore a coil of rope across her body, a canvas satchel, and her uncle’s tool roll at her belt.

“No,” Jack said.

“I agree,” she said. “We absolutely should not climb it.”

He looked at the satchel.

“Bread,” she said. “Chalk. Two water bottles. A blanket. Because when you climb it without me, I would prefer not to recover your frozen corpse.”

“I wasn’t going to climb.”

Nell looked at him.

“Not yet.”

“Of course not.”

A movement passed high above. The stalk shuddered. One of the great leaves folded suddenly, as though something in the cloud had brushed against it.

Jack imagined a hand reaching down through the vapor. If the Morrows discovered the road, they might cut it. Or they might use it.

“We only need to see where it goes,” he said.

“That sentence has killed more people than plague.”

“We climb to the cloud, look around, and come straight back.”

“I knew you were going to say that. I dislike you for making preparation look like agreement.”

He tied the rope around his waist. Nell checked the knot and retied it properly.

They had reached the height of the cottage roof when Jack’s mother came out.

“Jack.”

He looked down.

The villagers had gone still. His mother stood among them, one hand gripping the doorframe. From above, she looked smaller than she ever had in his life.

“Come down,” she said.

“We’re only going to look.”

“Come down now.”

The stalk trembled again. Jack looked down at his mother’s hand gripping the doorframe, then up at the cloud.

He climbed.

His mother shouted his name. Nell swore and followed.

The cottage sank beneath the leaves.

At first the climb was easy. The stems were ridged and warm beneath Jack’s hands, and the leaf joints made broad green platforms where they could rest. Ladybirds the size of dinner plates crawled through forests of silver hairs. Pale flowers opened as Jack passed, breathing out the smell of vanilla and wet earth. From one bell-shaped blossom came a flock of white moths, dry-winged and perfect, although the flower had been closed until that moment.

The valley widened below them. Hedgerows became dark stitching. The river caught the morning and turned to beaten metal. Jack saw the village square, the church, Wren’s yellow-gray house on the northern rise. He saw his own garden and, beside the stalk, one black speck that he knew was his mother.

The wind strengthened.

It pressed his coat against his body and tugged tears from his eyes. The stalk swayed in long, sickening arcs. When Jack looked up, the cloud seemed no closer; when he looked down, the earth had become impossibly distant. Nell climbed beneath him without speaking, her face pale around the mouth.

After an hour, they entered the weather.

Cold mist closed over them. Water gathered on Jack’s lashes and ran down his neck. The world shrank to green stem, white vapor, and the scrape of Nell’s boots. Leaves loomed suddenly out of the cloud and vanished behind them. Once lightning murmured somewhere near enough that Jack’s teeth ached.
