---
id: "jack-ch-05-giants-table"
book_id: "jack-house-above-rain"
part_id: "jack-part-02-above-rain"
title: "On the Giants’ Table"
cover_image_id: "jack-asset-05-table"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
wiki_mentions:
  - id: "jack-ch-05-giants-table-mention-jack"
    wiki_page_id: "jack-wiki-jack"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-nell"
    wiki_page_id: "jack-wiki-nell"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-lord-morrow"
    wiki_page_id: "jack-wiki-lord-morrow"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-lady-morrow"
    wiki_page_id: "jack-wiki-lady-morrow"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-majesty"
    wiki_page_id: "jack-wiki-majesty"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-harp"
    wiki_page_id: "jack-wiki-truth-harp"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-mother"
    wiki_page_id: "jack-wiki-jacks-mother"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-wren"
    wiki_page_id: "jack-wiki-silas-wren"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-cloud-house"
    wiki_page_id: "jack-wiki-cloud-house"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-bellweather"
    wiki_page_id: "jack-wiki-bellweather-valley"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
  - id: "jack-ch-05-giants-table-mention-weather-room"
    wiki_page_id: "jack-wiki-weather-room"
    source: "manual"
    created_at: "2026-08-22T12:00:00.000Z"
    updated_at: "2026-08-22T12:00:00.000Z"
---
For a moment Jack could not understand what he was seeing. The floor spread away like a wooden courtyard, each plank wider than a bed. A scarred table stood at its center on legs as thick as oaks. Iron pans hung against the far wall, black moons large enough to roof cottages. On the stove, a copper kettle breathed steam through the nostrils of a dragon. Its smallest teacup would have made a comfortable wash barrel; the teaspoon beside it was proportioned neatly enough for a giant’s hand and therefore as long as Jack was tall.

Magic moved through the domestic vastness. A knife chopped carrots by itself, each downward stroke shaking the board. A line of blue flames ran beneath the stove. Bells were fixed high on the walls where no giant could walk into them, their cords descending neatly beside the doorways like ship’s rigging. They rang one after another, and cupboards opened in answer.

Jack and Nell slipped along the wainscot, using shadows cast by jars and baskets. The house smelled of yeast, hot iron, rosemary, and rain. A loaf cooled on a rack above them, its crust a golden hill.

At the kitchen’s far end, a carved doorway opened into a gallery.

There the wonders became stranger.

The Morrows had arranged their possessions carefully. Nothing was heaped like treasure in a dragon’s cave. Human crowns rested beneath glass domes. A ship with silk sails floated in a bottle full of moving sea. In one case, a summer orchard grew in perfect miniature, every tree bent under red fruit. Beside it stood a row of labeled weather jars: *First Snow, North Marches, Year 608.* *Breath of the Western Gale.* *Rain Withheld from Bellweather, Late Barley Season.*

Jack’s skin prickled.

Nell pointed to a long cabinet containing familiar things: a silver christening cup from the chapel, Master Fen’s carved bedstead, the brass weathercock that had vanished from the school roof, three bolts of cloth bearing the mark of the village weaver. Each had a white card tied to it.

“Tax,” she read. “Tax. Penalty. Tax.”

A soft clucking came from the next room.

They followed it to a circular treasury. At its center, beneath a cage of black iron, sat a goose.

She was not giant-sized. Standing, she would have reached Jack’s chest. Her feathers were creamy white, each tipped with a metallic gleam, and thin lines of gold showed through the skin of her beak like cracks in porcelain. Around her neck was a heavy collar fitted with seven locks. Tubes descended into the cage from the ceiling. Through one rolled a wedding ring, through another a handful of silver coins, through a third several teeth from a carved ivory comb. The objects vanished into the collar with small, hard clicks.

The goose shuddered. Beneath her lay an egg of solid gold.

There were hundreds stacked behind the cage, each stamped with Lord Morrow’s seal.

“That,” Nell breathed, “is where it goes.”

Against the wall, on a giant writing desk, stood a harp.

It too was made for human hands. Rowanwood formed its pillar; its soundbox was dark with age and carved with birds whose wings seemed to stir in the firelight. Silver strings ran from neck to body. It was scarcely taller than Nell, a small ornament among the Morrows’ furniture.

As Jack approached, one string plucked itself.

The note was clear and cold. It passed through him like water.

“Coat,” the harp sang softly. “Brown wool. Spun by Margaret Alder. Sewn by Thomas Alder for his son, John. Recut by Alice Alder for her son—”

Jack seized the strings before it could finish.

The harp gave an offended twang.

“Don’t say it,” he whispered.

“Origin is not accusation,” the harp replied.

“It is if the house can hear.” Nell was examining the goose’s collar. “Can you prove where all this came from?”

Every string stirred.

Voices filled the treasury—not one voice but hundreds, braided into harmony.

“Ring, given by Mara Holt to Elian Holt, taken as drought levy in the thirty-eighth year. Comb, carved by Joseph Pike for his daughter, surrendered against rain debt. Silver, tithe of Bellweather village, assessed above covenant measure—”

“Stop,” Jack said.

The music ceased.

Nell looked at him. Neither needed to say what they had heard. The harp was not merely an instrument. It was the memory of the house.

A bell rang.

It was not one of the little kitchen bells. The sound rolled through the floor and set the golden eggs trembling in their stacks.

The goose flattened herself against the cage.

“Owners entering,” said a voice in the wall.

Nell grabbed Jack’s sleeve. They ran.

The house had changed behind them. The gallery doorway now opened into a dining hall they had never seen. At its center stood a table laid for two, vast and gleaming beneath chandeliers whose captive flames swam like goldfish in glass. The table legs offered the only nearby cover.

They scrambled up the carved foot, crossed a brace as wide as a bridge, and pulled themselves onto the seat of a chair. From there, the tabletop rose above their heads. Nell drove a small awl between two boards, used it as a step, and hauled herself over the edge. Jack followed as the dining hall doors opened.

They emerged beside a teacup painted with green herons. It stood higher than Jack’s shoulder. A silver spoon lay beyond it, its bowl broad as a shield. The white tablecloth rolled away in creased fields toward the opposite place setting.

Far below, the carpet covered the floor in a landscape of dark red flowers and blue rivers. Its woolen pile was deep enough to hide them if they could reach it. From the table edge, however, it might as well have been the valley seen from the beanstalk.

The giants entered.

Lord Morrow came first. He stood as tall as the church tower in Bellweather square, with a copper-colored beard divided into braids and fastened by seals of black iron. His skin had the warm gray cast of stone after rain. He wore a long dark coat whose buttons were gold coins larger than plates, and he carried a ledger beneath one arm.

Lady Morrow followed in a gown the color of an approaching storm. Her silver hair was woven into a crown of heavy braids; opals flashed at her throat like trapped lightning. Her face was beautiful in the severe manner of a winter landscape, and her eyes were a pale, luminous amber. Jack had expected ugliness. Her intelligence frightened him more.

They sat. The chair beneath Jack shifted, forcing him and Nell to flatten against the cup.

“The road has germinated,” Lord Morrow said.

His voice made the tea tremble.

Lady Morrow unfolded her napkin. “Wren?”

“Who else kept a seed?”

“You should have paid him.”

“I paid him generously.”

“You paid him two-thirds.”

“Which was generous after he disclosed the lower anchors to his wife.”

Lady Morrow lifted the dragon kettle. Steam curled around her hand. “His wife is dead.”

“Yes. The apothecary levy performed better than forecast.”

Jack felt Nell go very still beside him.

The giant poured. The stream struck the cup with the noise of a waterfall. Heat wrapped around Jack’s face.

“Then grief has made him imprudent,” Lady Morrow said. “The house will find whoever he sent.”

“Shall I have the road cut?”

“Leave it. A child who has climbed once will climb again, and I would rather they came up to us than we went down to them.”

“Groundborn are difficult to retain. They die in walls.”

“Only at first. The blue clock has served forty years.”

Something in the wall gave a faint, involuntary chime.

Lady Morrow’s head turned.

Her nostrils widened.

“Do you smell that?”

Lord Morrow paused with his cup halfway to his mouth.

“Wet wool,” he said.

“Earth below the rain.”

Her amber gaze traveled over the table.

Jack’s heart struck his ribs so hard he was sure she could hear it. Nell drew a thin screwdriver from her sleeve as if she intended to oppose a creature the size of a bell tower with it.

On the distant desk, the harp plucked one bright note.

Lady Morrow looked toward the sound.

A brass tuning peg sprang from the harp’s neck. It hit the floor, bounced, and rolled beneath the table.

At once the chair moved.

Its back swung toward the giants, its seat tilting just enough to send Jack and Nell sliding across the tablecloth. They caught the silver spoon. It spun beneath their weight. Jack clung to the handle while Nell seized the edge of the tablecloth and slashed it with her tool.

The fabric tore.

They dropped with it.

For an instant Jack saw the whole room turning around him: Lady Morrow rising, the table blazing with silver and porcelain, the patterned carpet rushing upward. The torn cloth caught on the chair brace and snapped tight. Jack slammed against wool. Nell landed beside him in a spray of silverware.

They slid down the hanging cloth and fell the final few feet into the carpet.

Its red-and-blue fibers closed over their heads like reeds.

A giant hand struck the floor behind them.

They ran beneath the woolen canopy. Every footstep sent a shudder through the ground. The giant tore back the carpet, exposing swaths of polished floor. Nell found the fallen tuning peg and snatched it up. It was warm in her hand and singing too high for Jack to hear except as a pain in his teeth.

“This way,” she gasped.

The note guided them to the wainscot. A little door sprang open. They threw themselves through just as Lady Morrow’s fingers swept across the boards.

“The house knows your breath now,” she said beyond the wall. Her voice had become very calm. “It will have your names before nightfall.”

The passage buckled and changed. Doors opened onto brick, rain, closets full of whispering coats. The tuning peg pulled in Nell’s grip whenever they turned the wrong way. They followed it through the walls, across a copper pipe hot with lightning, and out into the weather garden.

The beanstalk thrashed in the wind.

Jack went over the wall first. Nell followed. A shadow crossed the cloud behind them as Lady Morrow stepped into the garden.

She did not climb. She stood between the rain lilies, silver hair lifting in the storm, and watched them descend.

“Run down to your little houses,” she called. “Tell them the rain is due.”

Above her, the thunder tree opened its white branches.

The storm struck.

* * *

They climbed through hail, rain, and darkness.

Jack remembered little of the descent afterward. His hands bled. Twice his boots slipped from the wet stalk and the rope between him and Nell caught his weight. Lightning traveled through the vine in green-white veins. The valley rose through the mist at an agonizing slowness.

When he reached the lowest branches, arms seized him.

His mother pulled him off the stalk so hard that they both fell into the mud. For one breath she held him against her. Jack felt her heart pounding through her wet dress and smelled soap, smoke, and rain.

Then she pushed him back.

“You climbed after I told you to come down.”

His teeth were chattering. “Yes.”

“You saw me standing there.”

“Yes.”

She looked as if she might strike him, embrace him again, or do both. Instead she caught his face between her cracked hands and inspected him for injuries with furious thoroughness.

Nell dropped from the vine beside them. “Before anyone kills him, may we go indoors?”

Silas Wren stood near the cottage wrapped in a black cloak, his face lifted toward the storm. Jack’s mother turned on him.

“You,” she said.

Wren took one prudent step backward.

Inside, she made Jack and Nell strip off their wet coats, wrapped them in blankets, and put hot bricks beneath their feet. She did this without gentleness and without once suggesting that they were forgiven.

“We found the taxes,” Jack said when he could speak. “All of them. They feed everything into a goose. It lays gold.”

“Of course it does,” his mother said. “Why should anything about today be reasonable?”

Nell set the brass tuning peg on the table.

It sang.

At first only a single silver note emerged. Then the air above it filled with voices.

“Rain of Bellweather Valley,” sang the harp from impossibly far away. “Held during barley season by order of Lady Morrow. Released after harvest under classification of surplus. Winter levy assessed at one and one-sixth covenant measure. Excess retained—”

Jack’s mother sat down.

The peg went on. It named the silver brooch she had sold. It named the tax merchant who bought it and the clerk who carried it up the chain elevator. It named the goose’s collar and the gold egg into which the brooch had been transformed.

When the music ended, no one spoke.

At last his mother looked at Jack.

“You were right about the beans,” she said. “You were wrong to climb after I told you to stop. Those are different things.”

“Yes,” Jack said.

“This may not be the best moment to sound surprised,” Nell advised him.

Wren picked up the tuning peg. Tears stood in his old blue eyes, though whether for Ada or the gold, Jack could not tell.

“The harp remembers,” he murmured. “I wondered if it still could.”

“You knew about it?” Jack said.

“It was made for a southern king who believed every object should testify to its ownership. The Morrows acquired it when the king lost a war.”

“According to the harp, they acquired it as a penalty for unauthorized sunshine,” Nell said.

Wren’s mouth tightened. “The distinction is narrow.”

Jack’s mother reached across the table and took the old plans from beneath his cloak.

“What else did you fail to tell them?” she asked.

Wren was silent.

She unrolled the plans among the pie crumbs. Five black lines ran from the weather engine in the cloud-house to anchor stones across the valley. A sixth, newly green in Wren’s notation, connected the engine to the beanstalk.

“The road joins the systems,” she said.

“Temporarily.”

“And if it is cut?”

“The road? Nothing. It was never load-bearing. The house stood for fifty years without it.”

Her finger moved to the five black lines. “These.”

Wren looked toward the window. “Break the anchors, and the Morrows come down.”

“How quickly?”

“Quickly enough.”

“On top of what?”

He did not answer.

Jack saw the valley as he had seen it from above: cottages no larger than pale stones, cattle black dots in the fields, the church directly beneath the southern edge of the cloud.

“You meant to crash it,” he said.

Wren’s hands closed around the table edge.

“They let her die for a levy worth less to them than one button on his coat.”

“And how many wives do you propose to bury under their house?” Jack’s mother asked.

“You heard what they have done.”

“I did. I also heard my son tell me there are people trapped in its walls.”

“They are beyond saving.”

“That is an answer people give when saving someone would interfere with revenge.”

Wren flinched as if she had struck him.

Jack’s mother bent over the plans. She followed each suspension line with one blunt, reddened finger. Then she took three pieces of mending thread from the basket, tied them to the handle of a wooden spoon, and passed their ends to Jack, Nell, and Wren.

“Pull,” she said.

They did. The spoon rose from the table.

She told Nell to let her thread slide gradually through her fingers. The spoon tilted toward her but remained suspended.

“Cut yours,” she told Wren.

He did. The spoon lurched. The other threads burned across Jack’s fingers, and the handle struck the table.

“A suspension field is not washing on a line,” Wren said.

“No. Washing is less forgiving. If one line slackens, I shorten another. If the whole load must come down, I pay them out together.” She looked at the circular weather engine on the plan. “You raised the house. Can it be lowered?”

Wren stared at her.

His anger did not vanish. Jack saw it resisting the idea, searching for reasons to deny it. But beneath the grief, Wren was still the man who had designed the thing. His gaze sharpened.

“The weather key reverses the current,” he said slowly. “If the anchors are turned to release rather than severed…”

“How many people?”

“Five crews. One at each stone.”

“And someone in the house.”

Wren looked at Jack and Nell.

His mother did too.

The anger left her face then. What replaced it was worse.