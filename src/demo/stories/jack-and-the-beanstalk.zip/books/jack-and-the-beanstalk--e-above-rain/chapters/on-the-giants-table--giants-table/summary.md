---
id: "jack-ch-05-giants-table-summary"
chapter_id: "jack-ch-05-giants-table"
pov: "Jack"
characters:
  - "Jack"
  - "Nell"
  - "Lord Morrow"
  - "Lady Morrow"
  - "Majesty"
  - "The Harp"
  - "Jack's Mother"
  - "Silas Wren"
beats:
  - "Jack and Nell discover Bellweather’s taxes transformed into golden eggs."
  - "The truth-telling harp helps them escape the Morrows with one of its tuning pegs."
  - "Back in the valley, the peg proves the theft and reveals how the cloud-house can be lowered."
spoilers_ok: true
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
Inside the gigantic kitchen and treasury, Jack and Nell find stolen human treasures, a goose forced to turn taxes into golden eggs, and a harp compelled to testify truthfully about ownership. Lord and Lady Morrow nearly catch them on the dining table, but the house spirits help the children escape with one of the harp’s tuning pegs. Back below, the peg proves what happened to Bellweather’s wealth, and Jack’s mother helps Wren discover that coordinated control of the five anchors could lower the house safely.