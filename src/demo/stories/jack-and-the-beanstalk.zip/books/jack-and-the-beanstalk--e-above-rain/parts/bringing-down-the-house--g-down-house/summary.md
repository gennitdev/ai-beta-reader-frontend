---
id: "jack-part-03-summary"
part_id: "jack-part-03-bring-down-house"
characters:
  - "Jack"
  - "Nell"
  - "Jack's Mother"
  - "Silas Wren"
  - "Lord Morrow"
  - "Lady Morrow"
  - "Majesty"
  - "The Harp"
  - "Dapple"
beats:
  - "The village prepares the anchors."
  - "The goose is freed."
  - "The house descends to the moor."
  - "The Morrows become answerable to Bellweather."
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
Bellweather organizes around the five anchors while Jack and Nell return to free the goose and turn the weather key. The valley crews bring the cloud-house safely down, the harp identifies the Morrows’ stolen wealth, and a negotiated settlement returns both resources and control of the weather to the community.