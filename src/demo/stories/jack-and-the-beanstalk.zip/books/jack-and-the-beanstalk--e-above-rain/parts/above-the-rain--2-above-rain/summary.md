---
id: "jack-part-02-summary"
part_id: "jack-part-02-above-rain"
characters:
  - "Jack"
  - "Nell"
  - "Jack's Mother"
  - "Silas Wren"
  - "Lord Morrow"
  - "Lady Morrow"
  - "Majesty"
  - "The Harp"
beats:
  - "The beanstalk reaches the cloud."
  - "Jack and Nell enter the living house."
  - "They find Bellweather’s stolen wealth."
  - "The harp’s tuning peg reveals how the house can descend."
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
The beanstalk creates a road into the Morrows’ impossible estate. Jack and Nell discover that Bellweather’s taxes are being transformed into golden eggs and escape with proof from a truth-telling harp. Their evidence gives Jack’s mother and Silas Wren the information needed to devise a plan for lowering the cloud-house.