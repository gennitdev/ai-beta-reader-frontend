---
id: "jack-part-01-summary"
part_id: "jack-part-01-bargain"
characters:
  - "Jack"
  - "Jack's Mother"
  - "Nell"
  - "Silas Wren"
  - "Dapple"
beats:
  - "A new levy threatens Jack’s family."
  - "Wren reveals his history with the Morrows."
  - "Jack trades Dapple for the beans."
  - "The discarded beans begin to grow."
generated_by: "user"
model: null
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T12:00:00.000Z"
---
Bellweather’s worsening rain taxes force Jack and his mother to sell Dapple. Jack instead trades the cow to Silas Wren for magical beans that can grow a maintenance road to the giants’ cloud-house. His mother rejects the bargain and throws the beans away, but they take root during the night.