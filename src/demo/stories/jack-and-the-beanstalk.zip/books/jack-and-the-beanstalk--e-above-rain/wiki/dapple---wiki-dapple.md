---
id: "jack-wiki-dapple"
book_id: "jack-house-above-rain"
page_name: "Dapple"
page_type: "character"
summary: "Jack and his mother’s brindled cow, traded to Wren and eventually returned home."
aliases: []
tags:
  - "animal"
  - "family"
is_major: false
created_by_ai: false
is_pinned: false
cover_image_id: "jack-asset-09-part-bargain"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Dapple is a brindled brown-and-cream cow with one crooked horn. Jack helped care for her from birth, making his decision to trade her especially painful. Wren keeps her safely through the conflict and returns her after the settlement.