---
id: "jack-wiki-jacks-cottage"
book_id: "jack-house-above-rain"
page_name: "Jack's Cottage"
page_type: "location"
summary: "Jack and his mother’s patched cottage at the end of a muddy lane."
aliases:
  - "the cottage"
tags:
  - "home"
is_major: false
created_by_ai: false
is_pinned: false
cover_image_id: "jack-asset-03-beanstalk"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
The cottage is both home and workplace, crowded with washing, mending, spinning, and baking. The magical beans take root in its garden beside the pear tree, and the beanstalk rises from there into the Morrows’ cloud.