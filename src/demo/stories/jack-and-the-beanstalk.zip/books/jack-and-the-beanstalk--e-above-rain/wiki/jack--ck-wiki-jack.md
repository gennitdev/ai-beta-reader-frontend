---
id: "jack-wiki-jack"
book_id: "jack-house-above-rain"
page_name: "Jack"
page_type: "character"
summary: "A fourteen-year-old Bellweather boy whose desperate bargain opens a road to the giants."
aliases: []
tags:
  - "protagonist"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-12-jack-portrait"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Jack lives with his mother in Bellweather Valley. He is impulsive, observant, and determined to escape the poverty created by the Morrows’ weather taxes. His bargain with Silas Wren costs his mother her cow and leads him to confront both the giants and the harm caused by making choices with someone else’s livelihood.