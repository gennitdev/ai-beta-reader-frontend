---
id: "jack-wiki-nell"
book_id: "jack-house-above-rain"
page_name: "Nell"
page_type: "character"
summary: "Jack’s mechanically gifted friend and partner in both climbs to the cloud-house."
aliases: []
tags:
  - "friend"
  - "mechanic"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-13-nell-portrait"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Nell is fifteen and apprenticed informally to her uncle, who repairs locks, watches, and mill gears. She is skeptical, blunt, technically capable, and intensely loyal. Her tools and understanding of mechanisms repeatedly make the difference inside the Morrows’ house.