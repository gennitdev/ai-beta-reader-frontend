---
id: "jack-wiki-jacks-mother"
book_id: "jack-house-above-rain"
page_name: "Jack's Mother"
page_type: "character"
summary: "Jack’s hardworking mother, who turns the village’s anger into a coordinated plan."
aliases:
  - "Mam"
tags:
  - "family"
  - "organizer"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-14-mother-portrait"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Jack’s mother is thirty-nine, practical, sharp-witted, and exhausted by years of labor after her husband’s death. She washes, mends, spins, bakes, and takes whatever work will keep them alive. She fiercely opposes Jack’s reckless bargain, but later designs the coordinated anchor operation that brings the cloud-house safely to earth.