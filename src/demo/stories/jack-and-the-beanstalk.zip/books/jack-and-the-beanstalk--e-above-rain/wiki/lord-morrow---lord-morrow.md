---
id: "jack-wiki-lord-morrow"
book_id: "jack-house-above-rain"
page_name: "Lord Morrow"
page_type: "character"
summary: "A giant who rules Bellweather’s weather and taxation from the cloud-house."
aliases: []
tags:
  - "giant"
  - "antagonist"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-img-15"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Lord Morrow is a copper-bearded giant and co-owner of the cloud-house. He treats Bellweather’s weather, taxes, and labor as contractual property. When the house is lowered, he remains dangerous but loses the distance and machinery that made him seem untouchable.