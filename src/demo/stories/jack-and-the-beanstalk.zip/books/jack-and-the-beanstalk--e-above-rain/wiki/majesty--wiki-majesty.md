---
id: "jack-wiki-majesty"
book_id: "jack-house-above-rain"
page_name: "Majesty"
page_type: "character"
summary: "A captive goose forced by giant machinery to turn stolen valuables into golden eggs."
aliases:
  - "the goose"
  - "the golden goose"
tags:
  - "animal"
  - "magic"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-06-goose"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Majesty is the name Nell gives the white goose imprisoned in the Morrows’ treasury. A mechanical collar forces her to transform Bellweather’s taxes into golden eggs. Once freed, she stops laying gold, moves into Wren’s byre, and develops strong opinions about both turnips and machinery.