---
id: "jack-wiki-truth-harp"
book_id: "jack-house-above-rain"
page_name: "The Harp"
page_type: "character"
summary: "An enchanted harp compelled to testify truthfully about the ownership of objects."
aliases:
  - "the truth-telling harp"
tags:
  - "enchanted-object"
  - "witness"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-18-harp"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
The human-sized harp was made for a king who wanted every object to testify to its ownership. The Morrows acquired it after a war and kept it caged near their treasury. Its tuning peg carries testimony to Bellweather, and its final song identifies the valley’s stolen wealth.