---
id: "jack-wiki-bellweather-valley"
book_id: "jack-house-above-rain"
page_name: "Bellweather Valley"
page_type: "location"
summary: "A farming valley whose weather and wealth are controlled by the Morrows."
aliases:
  - "Bellweather"
tags:
  - "valley"
  - "community"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-01-cloud"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Bellweather Valley lies beneath the Morrows’ stationary cloud. Its farms suffer from withheld rain, destructive releases, and levies supposedly charged for weather management. Five anchor stones connect the valley to the suspended estate. After the settlement, control of the weather key is divided among five districts.