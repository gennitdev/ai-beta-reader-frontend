---
id: "jack-wiki-weather-garden"
book_id: "jack-house-above-rain"
page_name: "The Weather Garden"
page_type: "location"
summary: "A walled cloud-house garden where the Morrows cultivate weather as plants and fruit."
aliases: []
tags:
  - "magic"
  - "cloud-house"
is_major: false
created_by_ai: false
is_pinned: false
cover_image_id: "jack-asset-10-part-weather-garden"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
The weather garden contains rain lilies, hail-plums, glass fruit holding tiny winds, and a white thunder tree. It surrounds the upper end of Wren’s living maintenance road and provides Jack and Nell’s first entrance to the estate.