---
id: "jack-wiki-silas-wren"
book_id: "jack-house-above-rain"
page_name: "Silas Wren"
page_type: "character"
summary: "The former artificer who raised the Morrows’ estate and kept the last maintenance-road seeds."
aliases:
  - "Wren"
tags:
  - "artificer"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-09-part-bargain"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Silas Wren is an elderly artificer of weather, suspension, and architectural impossibilities. He built the cloud-house and its five anchors but received only two of the three measures of gold promised to him. After his wife Ada dies, he trades Jack the final magical beans and later helps plan the house’s descent.