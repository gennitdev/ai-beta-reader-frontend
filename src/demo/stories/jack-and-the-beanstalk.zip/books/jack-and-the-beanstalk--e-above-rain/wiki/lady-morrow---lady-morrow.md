---
id: "jack-wiki-lady-morrow"
book_id: "jack-house-above-rain"
page_name: "Lady Morrow"
page_type: "character"
summary: "The precise and formidable giant who manages the cloud-house and its defenses."
aliases: []
tags:
  - "giant"
  - "antagonist"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-img-16"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Lady Morrow is a silver-haired giant with amber eyes and exacting control over the estate. She recognizes that Jack and Nell may return and uses the living house to learn their identities. Her control begins to fail when the bound spirits side with the children.