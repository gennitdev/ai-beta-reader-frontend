---
id: "jack-wiki-weather-room"
book_id: "jack-house-above-rain"
page_name: "The Weather Room"
page_type: "location"
summary: "The central control room connecting the cloud-house to Bellweather’s five anchors."
aliases: []
tags:
  - "machinery"
  - "cloud-house"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-11-part-descent"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
The weather room is a circular chamber beneath a glass dome, with the valley visible through a column of transparent air. Its regulator and great weather key control the suspension field. Turning the key while five crews coordinate the anchors allows the estate to descend.