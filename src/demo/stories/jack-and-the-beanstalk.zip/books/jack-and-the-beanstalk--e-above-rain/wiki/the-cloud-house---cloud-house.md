---
id: "jack-wiki-cloud-house"
book_id: "jack-house-above-rain"
page_name: "The Cloud-House"
page_type: "location"
summary: "The Morrows’ immense living estate, suspended above Bellweather by weather machinery and five anchors."
aliases:
  - "the Morrows’ estate"
tags:
  - "magic"
  - "giants"
is_major: true
created_by_ai: false
is_pinned: true
cover_image_id: "jack-asset-04-climbing"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
The cloud-house is built from black stone, dark timber, green glass, and copper weather machinery. Its rooms are sized for giants, its windows look onto other seasons, and bound spirits inhabit its doors, clocks, furniture, and tools. Silas Wren raised it above Bellweather, where condensed vapor hid its lower stories until the valley brought it down to the moor.
