---
id: "jack-wiki-wrens-house"
book_id: "jack-house-above-rain"
page_name: "Wren's House"
page_type: "location"
summary: "Silas Wren’s mossy former workshop on the road north of Bellweather."
aliases: []
tags:
  - "workshop"
is_major: false
created_by_ai: false
is_pinned: false
cover_image_id: "jack-asset-09-part-bargain"
created_at: "2026-08-22T12:00:00.000Z"
updated_at: "2026-08-22T18:00:00.000Z"
---
Wren’s small stone house contains books, copper planetary models, old plans, and remnants of his work as an artificer. Ada’s grave lies beside its path. Its empty byre becomes Dapple’s temporary home and later Majesty’s permanent one.